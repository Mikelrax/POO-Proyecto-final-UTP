import javax.swing.SwingUtilities;
import views.LoginForm;
public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginForm().setVisible(true);
        });
    }
}
