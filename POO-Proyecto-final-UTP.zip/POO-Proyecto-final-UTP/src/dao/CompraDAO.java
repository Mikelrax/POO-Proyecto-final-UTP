package dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CompraDAO {

    public List<Object[]> buscarCompras(String dniCliente, String libro, java.util.Date desde, java.util.Date hasta) {
        List<Object[]> resultados = new ArrayList<>();

        String sql = """
        SELECT c.numero, cl.nombre_completo, l.titulo, c.fecha, c.total
        FROM Compra c
        JOIN Cliente cl ON c.cliente_id = cl.id
        JOIN DetalleCompra dc ON dc.compra_id = c.numero
        JOIN Libro l ON dc.libro_codigo = l.codigo
        WHERE cl.dni = ?
          AND l.titulo ILIKE ?
          AND c.fecha BETWEEN ? AND ?
        ORDER BY c.fecha DESC
    """;

        try (Connection conn = ConexionDB.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, dniCliente);
            stmt.setString(2, "%" + libro + "%");
            stmt.setDate(3, new java.sql.Date(desde.getTime()));
            stmt.setDate(4, new java.sql.Date(hasta.getTime()));

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[]{
                        rs.getInt("numero"),
                        rs.getString("nombre_completo"),
                        rs.getString("titulo"),
                        rs.getDate("fecha"),
                        String.format("S/ %.2f", rs.getDouble("total"))
                };
                resultados.add(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return resultados;
    }}


