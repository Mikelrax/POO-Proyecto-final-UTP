package dao;

import modelo.Usuario;

import java.sql.*;

public class UsuarioDAO {
    public Usuario autenticar(String correo, String contraseña) {
        try (Connection conn = ConexionDB.conectar()) {
            String sql = "SELECT * FROM Usuario WHERE correo = ? AND contraseña = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, correo);
            stmt.setString(2, contraseña);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Usuario u = new Usuario();
                u.setId(rs.getInt("id"));
                u.setNombreCompleto(rs.getString("nombre_completo"));
                u.setCorreo(rs.getString("correo"));
                u.setDni(rs.getString("dni"));
                u.setContraseña(rs.getString("contraseña"));
                return u;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean registrar(Usuario u) {
        try (Connection conn = ConexionDB.conectar()) {
            String sql = "INSERT INTO Usuario (nombre_completo, correo, dni, direccion, contraseña) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, u.getNombreCompleto());
            stmt.setString(2, u.getCorreo());
            stmt.setString(3, u.getDni());
            stmt.setString(5, u.getContraseña());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
