package dao;
import java.sql.*;
import modelo.Cliente;

public class ClienteDAO {

    public boolean registrar(Cliente c) {
        boolean registrado = false;
        try (Connection conn = ConexionDB.conectar()) {
            String sql = "INSERT INTO cliente(dni, nombre, correo, telefono, direccion) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, c.getDni());
            ps.setString(2, c.getNombreCompleto());
            ps.setString(3, c.getCorreo());
            ps.setString(4, c.getTelefono());
            ps.setString(5, c.getDireccion());
            registrado = ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return registrado;
    }

    public Cliente buscarPorDNI(String dni) {
        Cliente cliente = null;
        try (Connection conn = ConexionDB.conectar()) {
            String sql = "SELECT * FROM cliente WHERE dni = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, dni);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                cliente = new Cliente();
                cliente.setDni(rs.getString("dni"));
                cliente.setNombreCompleto(rs.getString("nombre"));
                cliente.setCorreo(rs.getString("correo"));
                cliente.setTelefono(rs.getString("telefono"));
                cliente.setDireccion(rs.getString("direccion"));
            }


    } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return cliente;
    }}
