package views;
import javax.swing.*;
import java.awt.event.*;

import dao.ClienteDAO;
import modelo.Usuario;
import modelo.Cliente;
import dao.UsuarioDAO;

public class RegistroForm extends JFrame {
    private JTextField txtNombre, txtCorreo, txtDni, txtDireccion;
    private JPasswordField txtPassword;
    private JButton btnRegistrar;

    public RegistroForm() {
        setTitle("Registro de Usuario");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel lblNombre = new JLabel("Nombre completo:");
        lblNombre.setBounds(20, 20, 120, 25);
        add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(150, 20, 200, 25);
        add(txtNombre);

        JLabel lblCorreo = new JLabel("Correo electrónico:");
        lblCorreo.setBounds(20, 60, 120, 25);
        add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(150, 60, 200, 25);
        add(txtCorreo);

        JLabel lblDni = new JLabel("DNI:");
        lblDni.setBounds(20, 100, 120, 25);
        add(lblDni);

        txtDni = new JTextField();
        txtDni.setBounds(150, 100, 200, 25);
        add(txtDni);

        JLabel lblDireccion = new JLabel("Dirección:");
        lblDireccion.setBounds(20, 140, 120, 25);
        add(lblDireccion);

        txtDireccion = new JTextField();
        txtDireccion.setBounds(150, 140, 200, 25);
        add(txtDireccion);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(20, 180, 120, 25);
        add(lblPass);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(150, 180, 200, 25);
        add(txtPassword);

        btnRegistrar = new JButton("Registrar");
        btnRegistrar.setBounds(140, 220, 120, 30);
        add(btnRegistrar);

        btnRegistrar.addActionListener(e -> {
            Usuario u = new Usuario();
            u.setNombreCompleto(txtNombre.getText());
            u.setCorreo(txtCorreo.getText());
            u.setDni(txtDni.getText());
            u.setContraseña(new String(txtPassword.getPassword()));

            Cliente c = new Cliente();
            c.setNombreCompleto(txtNombre.getText());
            c.setCorreo(txtCorreo.getText());
            c.setDni(txtDni.getText());
            c.setDireccion(txtDireccion.getText());

            UsuarioDAO udao = new UsuarioDAO();
            ClienteDAO cdao = new ClienteDAO();

            boolean usuarioRegistrado = udao.registrar(u);
            boolean clienteRegistrado = cdao.registrar(c);

            if (usuarioRegistrado && clienteRegistrado) {
                JOptionPane.showMessageDialog(this, "Registro exitoso. Ya puedes iniciar sesión.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error en el registro. Verifica los datos.");
            }
        });

        setVisible(true);
    }
}