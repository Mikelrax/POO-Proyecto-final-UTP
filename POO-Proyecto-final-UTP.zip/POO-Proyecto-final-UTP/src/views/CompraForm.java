package views;

import modelo.DetalleCompra;
import modelo.Libro;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CompraForm extends JFrame {
    private String dniCliente;

    private JComboBox<String> cboCategoria;
    private JTable tblLibros;
    private JButton btnAgregarCarrito, btnFinalizarCompra;
    private JTable tblCarrito;
    private JLabel lblSubtotal, lblIGV, lblTotal;

    private List<Libro> librosDisponibles = new ArrayList<>();
    private List<DetalleCompra> carrito = new ArrayList<>();

    public CompraForm(String dniCliente) {
        this.dniCliente = dniCliente;

        setTitle("Registro de Compra");
        setSize(800, 600);
        setLayout(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel lblCat = new JLabel("Categoría:");
        lblCat.setBounds(20, 20, 80, 25);
        add(lblCat);

        cboCategoria = new JComboBox<>();
        cboCategoria.setBounds(100, 20, 200, 25);
        cboCategoria.addItem("Todas");
        // Aquí puedes cargar categorías reales desde la BD si tienes DAO implementado
        add(cboCategoria);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(310, 20, 100, 25);
        add(btnBuscar);

        tblLibros = new JTable(new DefaultTableModel(new Object[]{"Código", "Título", "Autor", "Precio"}, 0));
        JScrollPane sp1 = new JScrollPane(tblLibros);
        sp1.setBounds(20, 60, 740, 150);
        add(sp1);

        btnAgregarCarrito = new JButton("Agregar al carrito");
        btnAgregarCarrito.setBounds(300, 220, 160, 30);
        add(btnAgregarCarrito);

        tblCarrito = new JTable(new DefaultTableModel(new Object[]{"Título", "Cantidad", "P. Unitario", "Total"}, 0));
        JScrollPane sp2 = new JScrollPane(tblCarrito);
        sp2.setBounds(20, 260, 740, 150);
        add(sp2);

        lblSubtotal = new JLabel("Subtotal: S/ 0.00");
        lblSubtotal.setBounds(500, 420, 200, 25);
        add(lblSubtotal);

        lblIGV = new JLabel("IGV (18%): S/ 0.00");
        lblIGV.setBounds(500, 450, 200, 25);
        add(lblIGV);

        lblTotal = new JLabel("Total: S/ 0.00");
        lblTotal.setBounds(500, 480, 200, 25);
        add(lblTotal);

        btnFinalizarCompra = new JButton("Finalizar Compra");
        btnFinalizarCompra.setBounds(300, 520, 180, 30);
        add(btnFinalizarCompra);

        JButton btnBuscarCompras = new JButton("Buscar Compras");
        btnBuscarCompras.setBounds(20, 520, 160, 30);
        btnBuscarCompras.addActionListener(e -> new BusquedaComprasForm(dniCliente));
        add(btnBuscarCompras);

        // Eventos
        btnBuscar.addActionListener(e -> buscarLibros());
        btnAgregarCarrito.addActionListener(e -> agregarAlCarrito());
        btnFinalizarCompra.addActionListener(e -> finalizarCompra());

        setVisible(true);
    }

    private void buscarLibros() {
        String categoria = (String) cboCategoria.getSelectedItem();
        // Aquí deberías consultar a la base de datos por libros de esa categoría
        // Por ahora usaremos libros de prueba
        DefaultTableModel model = (DefaultTableModel) tblLibros.getModel();
        model.setRowCount(0);
        librosDisponibles.clear();

        Libro l1 = new Libro();
        l1.setCodigo(1);
        l1.setTitulo("El Principito");
        l1.setAutor("Antoine de Saint-Exupéry");
        l1.setPrecio(35.50);
        librosDisponibles.add(l1);

        Libro l2 = new Libro();
        l2.setCodigo(2);
        l2.setTitulo("1984");
        l2.setAutor("George Orwell");
        l2.setPrecio(42.00);
        librosDisponibles.add(l2);

        for (Libro l : librosDisponibles) {
            model.addRow(new Object[]{l.getCodigo(), l.getTitulo(), l.getAutor(), l.getPrecio()});
        }
    }

    private void agregarAlCarrito() {
        int row = tblLibros.getSelectedRow();
        if (row >= 0) {
            Libro libro = librosDisponibles.get(row);
            String cantidadStr = JOptionPane.showInputDialog("Cantidad a agregar:");
            int cantidad = Integer.parseInt(cantidadStr);
            double total = libro.getPrecio() * cantidad;

            DetalleCompra detalle = new DetalleCompra();
            detalle.setLibro(libro);
            detalle.setCantidad(cantidad);
            detalle.setPrecioUnitario(libro.getPrecio());
            carrito.add(detalle);

            DefaultTableModel model = (DefaultTableModel) tblCarrito.getModel();
            model.addRow(new Object[]{libro.getTitulo(), cantidad, libro.getPrecio(), total});

            actualizarTotales();
        }
    }

    private void actualizarTotales() {
        double subtotal = 0.0;
        for (DetalleCompra d : carrito) {
            subtotal += d.getCantidad() * d.getPrecioUnitario();
        }
        double igv = subtotal * 0.18;
        double total = subtotal + igv;

        lblSubtotal.setText(String.format("Subtotal: S/ %.2f", subtotal));
        lblIGV.setText(String.format("IGV (18%%): S/ %.2f", igv));
        lblTotal.setText(String.format("Total: S/ %.2f", total));
    }

    private void finalizarCompra() {
        // Mostrar formulario para ingresar datos del cliente y guardar Compra y Detalles en BD
        JOptionPane.showMessageDialog(this, "Compra registrada correctamente.");
        dispose();
    }


}