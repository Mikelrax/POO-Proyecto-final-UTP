package views;
import dao.ClienteDAO;
import dao.CompraDAO;
import modelo.Cliente;
import java.util.Date;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;

public class BusquedaComprasForm extends JFrame {
    private JTextField txtCliente, txtLibro;
    private JSpinner spnDesde, spnHasta;
    private JButton btnBuscar;
    private JTable tblResultados;
    private DefaultTableModel modeloTabla;
    private String dniCliente;

    public BusquedaComprasForm(String dniCliente) {
        this.dniCliente = dniCliente;

        setTitle("Búsqueda de Compras");
        setSize(800, 500);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Etiqueta y campo no editable para mostrar el cliente autenticado
        JLabel lblCliente = new JLabel("Cliente:");
        lblCliente.setBounds(20, 20, 80, 25);
        add(lblCliente);

        txtCliente = new JTextField();
        txtCliente.setBounds(90, 20, 200, 25);
        txtCliente.setText(obtenerNombreClientePorDNI(dniCliente));
        txtCliente.setEnabled(false);
        add(txtCliente);

        JLabel lblLibro = new JLabel("Libro:");
        lblLibro.setBounds(320, 20, 60, 25);
        add(lblLibro);

        txtLibro = new JTextField();
        txtLibro.setBounds(380, 20, 200, 25);
        add(txtLibro);

        JLabel lblDesde = new JLabel("Desde:");
        lblDesde.setBounds(20, 60, 60, 25);
        add(lblDesde);

        spnDesde = new JSpinner(new SpinnerDateModel());
        spnDesde.setEditor(new JSpinner.DateEditor(spnDesde, "yyyy-MM-dd"));
        spnDesde.setBounds(90, 60, 130, 25);
        add(spnDesde);

        JLabel lblHasta = new JLabel("Hasta:");
        lblHasta.setBounds(240, 60, 60, 25);
        add(lblHasta);

        spnHasta = new JSpinner(new SpinnerDateModel());
        spnHasta.setEditor(new JSpinner.DateEditor(spnHasta, "yyyy-MM-dd"));
        spnHasta.setBounds(310, 60, 130, 25);
        add(spnHasta);

        btnBuscar = new JButton("Buscar");
        btnBuscar.setBounds(480, 60, 100, 25);
        add(btnBuscar);

        modeloTabla = new DefaultTableModel(new Object[]{"N° Compra", "Cliente", "Libro", "Fecha", "Total"}, 0);
        tblResultados = new JTable(modeloTabla);
        JScrollPane scroll = new JScrollPane(tblResultados);
        scroll.setBounds(20, 100, 740, 330);
        add(scroll);

        btnBuscar.addActionListener(e -> buscar());

        setVisible(true);
    }

    private String obtenerNombreClientePorDNI(String dni) {
        ClienteDAO dao = new ClienteDAO();
        Cliente c = dao.buscarPorDNI(dni);
        return c != null ? c.getNombreCompleto() : "No encontrado";
    }

    private void buscar() {
        modeloTabla.setRowCount(0);

        String tituloLibro = txtLibro.getText();
        Date desde = (Date) spnDesde.getValue();
        Date hasta = (Date) spnHasta.getValue();

        CompraDAO dao = new CompraDAO();
        List<Object[]> resultados = dao.buscarCompras(dniCliente, tituloLibro, desde, hasta);

        for (Object[] fila : resultados) {
            modeloTabla.addRow(fila);
        }
    }
}


