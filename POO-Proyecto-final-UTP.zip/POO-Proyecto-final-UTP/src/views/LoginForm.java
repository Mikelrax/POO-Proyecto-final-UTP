package views;

import dao.UsuarioDAO;
import modelo.Usuario;
import views.CompraForm;
import javax.swing.*;
import java.awt.event.*;

public class LoginForm extends JFrame {
    private JTextField txtCorreo;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnRegistro;

    public LoginForm() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel lblCorreo = new JLabel("Correo:");
        lblCorreo.setBounds(20, 20, 80, 25);
        add(lblCorreo);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(100, 20, 160, 25);
        add(txtCorreo);

        JLabel lblPass = new JLabel("Contraseña:");
        lblPass.setBounds(20, 60, 80, 25);
        add(lblPass);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(100, 60, 160, 25);
        add(txtPassword);

        btnLogin = new JButton("Ingresar");
        btnLogin.setBounds(40, 100, 100, 30);
        add(btnLogin);

        btnRegistro = new JButton("Registrarse");
        btnRegistro.setBounds(150, 100, 110, 30);
        add(btnRegistro);

        btnLogin.addActionListener(e -> {
            String correo = txtCorreo.getText();
            String pass = new String(txtPassword.getPassword());

            UsuarioDAO dao = new UsuarioDAO();
            Usuario u = dao.autenticar(correo, pass);

            if (u != null) {
                dispose();
                new CompraForm(u.getDni()); // ← PASA EL DNI
            } else {
                JOptionPane.showMessageDialog(this, "Credenciales incorrectas");
            }
        });

        btnRegistro.addActionListener(e -> {
            new RegistroForm();
        });


        setVisible(true);
    }

    public static void main(String[] args) {
        new LoginForm();
    }
}



